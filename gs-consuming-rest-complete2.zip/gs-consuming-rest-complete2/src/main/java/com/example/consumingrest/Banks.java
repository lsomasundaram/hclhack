package com.example.consumingrest;

import java.util.List;
import java.util.ArrayList;

public class Banks {

	private List<Bank> bankList;

	public List<Bank> getBankList() {
		if (bankList == null) {
			bankList = new ArrayList<Bank>();
		}
		return bankList;
	}

	public void setQuoteList(List<Bank> bankList) {
		bankList = bankList;
	}
	
}
