package com.example.consumingrest;

import java.net.URI; 
import org.springframework.beans 
    .factory.annotation.Autowired; 
import org.springframework.http 
    .ResponseEntity; 
import org.springframework.web.bind 
    .annotation.GetMapping; 
import org.springframework.web.bind 
    .annotation.PostMapping; 
import org.springframework.web.bind 
    .annotation.RequestBody; 
import org.springframework.web.bind 
    .annotation.RequestMapping; 
import org.springframework.web.bind 
    .annotation.RestController; 
import org.springframework.web.servlet 
    .support.ServletUriComponentsBuilder; 
  
// Import the above-defined classes 
// to use the properties of those 
// classes 
//import com.example.demo.Quotes; 
//import com.example.demo.QuoteDAO; 
//import com.example.demo.Quote; 
  
// Creating the REST controller 
@RestController
@RequestMapping(path = "/banks") 
public class BankController { 
  
    @Autowired
   private BankDAO bankDao; 
        
        // Implementing a GET method 
        // to get the list of all 
        // the employees 
   @GetMapping( 
        path = "/", 
        produces = "application/json") 
  
    public Banks getBanks() 
    { 
  
        return bankDao 
            .getAllBanks(); 
    } 
  
        
        // Create a POST method 
        // to add an employee 
        // to the list 
   @PostMapping( 
        path = "/", 
        consumes = "application/json", 
        produces = "application/json") 
  
    public ResponseEntity<Object> addBank( 
        @RequestBody Bank bank) 
    { 
  
        // Creating an ID of an employee 
        // from the number of employees 
        Integer id 
            = bankDao 
                  .getAllBanks() 
                  .getBankList() 
                  .size() 
              + 1; 
  
        bank.setName(""+id); 
  
        bankDao 
            .addBank(bank); 
  
        URI location 
            = ServletUriComponentsBuilder 
                  .fromCurrentRequest() 
                  .path("/{id}") 
                  .buildAndExpand( 
                      bank.getName() 
                  .toUri(); 
  
               return ResponseEntity 
            .created(location) 
            .build(); 
    } 
} 