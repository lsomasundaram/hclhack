package com.example.consumingrest;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Bank {

	private String name;
	private String bankCode;
	public Bank(String name, String bankCode) {
		super();
		this.name = name;
		this.bankCode = bankCode;
	}

	//private Value value;

	public Bank() {
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}



	@Override
	public String toString() {
		return "Bank [name=" + name + ", bankCode=" + bankCode + "]";
	}

	
}